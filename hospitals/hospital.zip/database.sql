CREATE DATABASE IF NOT EXISTS healthcare
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE healthcare;

CREATE TABLE IF NOT EXISTS hospitals (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    hospital_name VARCHAR(150) NOT NULL,
    username VARCHAR(80) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    address VARCHAR(255) DEFAULT NULL,
    city VARCHAR(100) DEFAULT NULL,
    phone VARCHAR(30) DEFAULT NULL,
    latitude DECIMAL(10,7) DEFAULT NULL,
    longitude DECIMAL(10,7) DEFAULT NULL,
    emergency_available TINYINT(1) NOT NULL DEFAULT 1,
    opening_time TIME DEFAULT NULL,
    closing_time TIME DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS hospital_beds (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    hospital_id INT UNSIGNED NOT NULL UNIQUE,
    general_total INT UNSIGNED NOT NULL DEFAULT 0,
    general_available INT UNSIGNED NOT NULL DEFAULT 0,
    icu_total INT UNSIGNED NOT NULL DEFAULT 0,
    icu_available INT UNSIGNED NOT NULL DEFAULT 0,
    emergency_total INT UNSIGNED NOT NULL DEFAULT 0,
    emergency_available INT UNSIGNED NOT NULL DEFAULT 0,
    CONSTRAINT fk_beds_hospital
        FOREIGN KEY (hospital_id) REFERENCES hospitals(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS hospital_doctors (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    hospital_id INT UNSIGNED NOT NULL,
    doctor_name VARCHAR(150) NOT NULL,
    specialization VARCHAR(120) NOT NULL,
    available TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_doctors_hospital
        FOREIGN KEY (hospital_id) REFERENCES hospitals(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_doctors_hospital (hospital_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS incoming_patients (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    hospital_id INT UNSIGNED NOT NULL,
    patient_name VARCHAR(150) NOT NULL,
    age TINYINT UNSIGNED DEFAULT NULL,
    gender VARCHAR(30) DEFAULT NULL,
    emergency_type VARCHAR(150) DEFAULT NULL,
    required_specialization VARCHAR(120) DEFAULT NULL,
    ambulance_number VARCHAR(50) DEFAULT NULL,
    driver_name VARCHAR(150) DEFAULT NULL,
    driver_phone VARCHAR(30) DEFAULT NULL,
    eta_minutes INT UNSIGNED DEFAULT NULL,
    status ENUM('Incoming', 'Arrived', 'Cancelled') NOT NULL DEFAULT 'Incoming',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_patients_hospital
        FOREIGN KEY (hospital_id) REFERENCES hospitals(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_patients_hospital_status (hospital_id, status),
    INDEX idx_patients_created_at (created_at)
) ENGINE=InnoDB;
